import React, { useEffect, useState } from 'react'
import Movies from './Components/Movies'


function App() {
  
  const [movies, setMovies] = useState([])

  useEffect(() => {

    fetchMovies()

  },[])

  const fetchMovies = () => {

    fetch('http://localhost:8080/api/movies')
      .then(response => response.json()) 
      .then(movies => {
        setMovies(movies)
      })

  }

  return (
    <Movies movies = {movies} onDeleted = {fetchMovies} />
    )

}

export default App;
