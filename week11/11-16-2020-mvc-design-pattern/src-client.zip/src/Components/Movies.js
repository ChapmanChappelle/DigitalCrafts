
function Movies(props) {

    const handleMovieDelete = (movie) => {
        deleteMovie(movie)
    }

    const deleteMovie = (movie) => {
        fetch(`http://localhost:8080/api/movies/${movie.id}`,{
            method: 'DELETE', 
            headers: {
                'Content-Type': 'application/json'
            }
        }).then(response => response.json())
        .then(result => {
            console.log(result)
            props.onDeleted() 
        })
            
    }


    const movieItems = props.movies.map(movie => {
        return <li key={movie.id}>{movie.title} - <button onClick = {() => handleMovieDelete(movie)}>Delete</button></li>
    })

    return <ul>{movieItems}</ul>
}

export default Movies 